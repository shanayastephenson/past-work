package calc;

import java.util.Deque;
import java.util.ArrayDeque;
import javax.swing.*;

/**
 * Class representing the internal state of the calculator. It is responsible
 * for keeping track of numbers entered and performing operations when buttons
 * are clicked. It tells the display what number to show.
 * 
 */
public class State {
	// Display on which results are written
	protected JTextField calcDisplay;

	// The stack to on which to store numbers.
	//
	// Note 1: If you implement the extra credit of adding floating point
	// operations,
	// then you will need to change the type parameter here, otherwise this
	// field should not be changed.
	//
	// Note 2: Deque<Integer> is an interface two reasonable implementing classes to
	// use
	// would be ArrayDeque and LinkedList.
	protected Deque<Integer> stack;
	protected int value;
	protected String valueString = "";
	protected char op;

	/**
	 * @param display
	 * 
	 */
	public State(JTextField display) {
		this.calcDisplay = display;
		this.stack = new ArrayDeque();
	}

	/**
	 * User clicked on a digit button ...
	 * 
	 * @pre: the state doesn't have anything in it
	 * @post: adds digits to the state
	 * @param value
	 */
	public void addDigit(int value) {
		this.value = value;
		valueString += Integer.toString(value);
		calcDisplay.setText(valueString);
	}

	/**
	 * User has clicked on operator button ...
	 * 
	 * @pre: there are two elements on the deque
	 * @post: operation is performed, new element put on the stack
	 * @param op
	 */
	public void doOp(char op) {

		String solution = new String();
		this.op = op;

		int a = stack.pop();
		int b = stack.pop();
		int c = 0;

		if (op == '+') {
			int added = (a + b);
			c = added;
		} else if (op == '-') {
			int subtracted = (a - b);
			c = subtracted;
		} else if (op == '*') {
			int multiplied = (a * b);
			c = multiplied;
		} else if (op == '/') {
			int divided = (a / b);
			c = divided;
		}

		stack.push(c);
		solution = Integer.toString(c);
		calcDisplay.setText(solution);
	}

	/**
	 * User clicked on enter button ...
	 * 
	 * @pre: there is a value on the deque
	 * @post: the valueString is set the empty string
	 */
	public void enter() {
		int valueOfString = Integer.parseInt(this.valueString);
		stack.push(valueOfString);
		valueString = "0";

	}

	/**
	 * User clicked on clear key ...
	 * 
	 * @pre: theres something on the deque
	 * @post: the deque is clear of any items and the display is set to 0
	 */
	public void clear() {
		stack.clear();
		calcDisplay.setText("0");
	}

	/**
	 * User clicked on pop key ...
	 * 
	 * @pre: there's something on the deque
	 * @post: the first element on the deque gets taken off and can be manipulated
	 */
	public void pop() {
		String solution = new String();
		int a = 0;
		if (stack.size() > 1) {
			stack.pop();
			a = stack.peekFirst();
		} else if (stack.isEmpty() || stack.size() < 1) {
			a = 0;
			stack.push(a);
		}

		solution = Integer.toString(a);
		calcDisplay.setText(solution);

	}

	/**
	 * User clicked on pop key ...
	 * 
	 * @pre: there's at least 2 elements on the deque
	 * @post: retrieves the first two elements from the deque and pushes them
	 */
	public void exchange() {
		String solution = new String();

		int a = stack.pop();
		int b = stack.pop();

		stack.push(a);
		stack.push(b);

		solution = Integer.toString(b);
		calcDisplay.setText(solution);
	}

	/**
	 * User clicked on the square root key ...
	 * 
	 * @pre: there's at least one element on the deque
	 * @post: retrieves element from the deque and multiplies in to itself
	 */

	public void squared() {
		String solution = new String();
		int a = stack.pop();
		a = a * a;
		stack.push(a);
		solution = Integer.toString(a);
		calcDisplay.setText(solution);

	}
}
