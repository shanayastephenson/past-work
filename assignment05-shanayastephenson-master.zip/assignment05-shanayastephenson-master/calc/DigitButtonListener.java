package calc;

import java.awt.event.*;

/**
 * Class representing buttons with numbers on them.
 * 
 * @author shanaya stephenson
 */
public class DigitButtonListener implements ActionListener {
	protected int newValue;
	protected State digitState;

	/**
	 * Button knows own value and the state so can communicate with it.
	 * 
	 * @param newValue
	 * @param state
	 */
	public DigitButtonListener(int newValue, State state) {
		this.newValue = newValue;
		this.digitState = state;

	}

	/**
	 * 
	 * @pre: User clicked on the button.
	 * @post: Informed state that it was clicked on and what its value is.
	 * @param: evt
	 */
	public void actionPerformed(ActionEvent evt) {
		digitState.addDigit(newValue);
	}
}
