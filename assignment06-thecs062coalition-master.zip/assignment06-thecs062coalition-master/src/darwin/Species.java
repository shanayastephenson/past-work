package darwin;

import java.io.*;
import java.util.ArrayList;

/**
 * The individual creatures in the world are all representatives of some
 * species class and share certain common characteristics, such as the species
 * name and the program they execute. Rather than copy this information into
 * each creature, this data can be recorded once as part of the description for
 * a species and then each creature can simply include the appropriate species
 * reference as part of its internal data structure.
 * <p>
 * 
 * To encapsulate all of the operations operating on a species within this
 * abstraction, this class provides a constructor that will read a file containing
 * the name of the creature and its program, as described in the earlier part
 * of this assignment. To make the folder structure more manageable, the
 * species files for each creature are stored in a subfolder named Creatures.
 * Thus, creating the Species for the file Hop.txt will cause the program to
 * read in "Creatures/Hop.txt".
 * <p>
 * 
 * Note: The instruction addresses start at one, not zero.
 */
public class Species {

	protected String name;
	protected String color;
	protected char speciesChar; // the first character of Species name
	protected ArrayList<Instruction> program;
	protected String[] splitStr;
	protected Instruction instruction;

	/**
	 * Create a species for the given file. 
	 * @pre fileName exists in the Creature subdirectory.
	 */
	public Species(BufferedReader fileReader) {
		program = new ArrayList<Instruction>();
		
		try {
			name = fileReader.readLine();
			color = fileReader.readLine();
			
			String str = fileReader.readLine();
			
			while (!str.equals("")) {
				splitStr = str.split(" ");
				int opcode = convert(splitStr);

				if (opcode < 5) {
					instruction = new Instruction(opcode, 0);
				} else {
					instruction = new Instruction(opcode, Integer.parseInt(splitStr[1]));	
				}				
				program.add(instruction);
				str = fileReader.readLine();
			}
			
		} catch (IOException e) {
			System.out.println(
				"Could not read file '"
					+ fileReader
					+ "'");
			System.exit(1);
		}
	}
	
	/**
	 * Convert string into opcode (int)
	 * @param splitStr instruction split into two parts
	 */
	public int convert(String[] splitStr) {
		String str = splitStr[0].toUpperCase();

		if (str.equals("HOP"))
			return Instruction.HOP;
		else if (str.equals("LEFT"))
			return Instruction.LEFT;
		else if (str.equals("RIGHT"))
			return Instruction.RIGHT;
		else if (str.equals("INFECT"))
			return Instruction.INFECT;
		else if (str.equals("IFEMPTY"))
			return Instruction.IFEMPTY;
		else if (str.equals("IFWALL"))
			return Instruction.IFWALL;
		else if (str.equals("IFSAME"))
			return Instruction.IFSAME;
		else if (str.equals("IFENEMY"))
			return Instruction.IFENEMY;
		else if (str.equals("IFRANDOM"))
			return Instruction.IFRANDOM;
		else if (str.equals("GO"))
			return Instruction.GO;
		else if (str.equals("IF2ENEMY")) {
			return Instruction.IF2ENEMY;

		}
		
		return 0;
	}

	/**
	* Return the char for the species
	*/
	public char getSpeciesChar() {
		return name.charAt(0);
	}

	/**
	 * Return the name of the species.
	 */
	public String getName() {
		return name;
	}

	/**
	 * Return the color of the species.
	 */
	public String getColor() {
		return color;
	}

	/**
	 * Return the number of instructions in the program.
	 */
	public int programSize() {
		return program.size();
	}

	/**
	 * Return an instruction from the program.
	 * @pre 1 <= i <= programSize().
	 * @post returns instruction i of the program.
	 */
	public Instruction programStep(int i) {
		if (i < 1 || i > program.size())
			throw new IndexOutOfBoundsException();
		return program.get(i-1);
	}

	/**
	 * Return a String representation of the program.
	 * 
	 * do not change
	 */
	public String programToString() {
		String s = "";
		for (int i = 1; i <= programSize(); i++) {
			s = s + (i) + ": " + programStep(i) + "\n";
		}
		return s;
	}
	
}
