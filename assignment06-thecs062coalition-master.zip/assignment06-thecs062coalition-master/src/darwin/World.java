package darwin;

import java.util.ArrayList;

import structure5.Matrix;

/**
 * This class includes the functions necessary to keep track of the creatures in
 * a two-dimensional world. There are many ways to implement this class but we
 * recommend looking at the Matrix class in Bailey's structure5 package.
 */

public class World<E> {

	protected Matrix<E> grid;
	protected ArrayList<E> creatureList;

	/**
	 * This function creates a new world consisting of height rows and width
	 * columns, each of which is numbered beginning at 0. A newly created world
	 * contains no objects.
	 */
	public World(int h, int w) {
		grid = new Matrix<E>(h, w);
		creatureList = new ArrayList<E>();
	}

	/**
	 * Returns the height of the world.
	 */
	public int height() {
		return grid.height();
	}

	/**
	 * Returns the width of the world.
	 */
	public int width() {
		return grid.width();
	}

	/**
	 * Returns whether pos is in the world or not.
	 * 
	 * @post returns true if pos is an (x,y) location within the bounds of the
	 *       board.
	 */
	public boolean inRange(Position pos) {
		return (pos.getX() >= 0 && pos.getY() >= 0 && pos.getX() < grid.width() && pos.getY() < grid.height());
	}

	/**
	 * Set a position on the board to contain c.
	 * 
	 * @pre pos is in range - throws IllegalArgumentException otherwise
	 */
	public void set(Position pos, E c) {
		if (!inRange(pos))
			throw new IllegalArgumentException();
		else {
			creatureList.remove(grid.get(pos.getX(), pos.getY()));
			grid.set(pos.getY(), pos.getX(), c);
			if (c != null)
				creatureList.add(c);
		}
	}

	/**
	 * Return the contents of a position on the board.
	 * 
	 * @pre pos is a in range - throws IllegalArgumentException otherwise
	 */
	public E get(Position pos) {
		if (!inRange(pos))
			throw new IllegalArgumentException();
		else
			return grid.get(pos.getY(), pos.getX());
	}

}
