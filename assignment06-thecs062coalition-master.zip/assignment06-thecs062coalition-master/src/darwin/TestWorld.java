package darwin;

import static org.junit.Assert.*;

import org.junit.Test;

public class TestWorld {
	World world;
	
	@Test
	public void testWorld() {
		assertTrue(world == null);
	}

	@Test
	public void testHeight() {
		world = new World(3, 6);
		assertEquals(world.height(), 3, 0);
	}

	@Test
	public void testWidth() {
		world = new World(3, 6);
		assertEquals(world.width(), 6, 0);
	}

	@Test
	public void testInRange() {
		world = new World(3, 6);
		Position pos1 = new Position(1, 2);
		Position pos2 = new Position(3, 6);
		Position pos3 = new Position(0, 0);
		Position pos4 = new Position(-1, -4);
		assertTrue(world.inRange(pos1));
		assertFalse(world.inRange(pos2));
		assertTrue(world.inRange(pos3));
		assertFalse(world.inRange(pos4));
	}

	@Test (expected = IllegalArgumentException.class)
	public void testSet() {
		world = new World(3, 6);
		Position pos1 = new Position(1,2);
		Position pos2 = new Position(3, 6);
		world.set(pos1, 5);
		world.set(pos2, 8);
		assertEquals(world.get(pos1), 5);
	}

	@Test (expected = IllegalArgumentException.class)
	public void testGet() {
		world = new World(3, 6);
		Position pos1 = new Position(1,2);
		Position pos2 = new Position(3, 6);
		
		assertEquals(world.get(pos1), null);
		
		world.set(pos1, 5);
		assertEquals(world.get(pos1), 5);
		
		world.set(pos2, 8);
		world.get(pos2);
		
	}

}
