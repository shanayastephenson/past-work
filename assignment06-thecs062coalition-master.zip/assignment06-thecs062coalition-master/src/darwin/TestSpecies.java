package darwin;

import static org.junit.Assert.*;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.NoSuchElementException;

import org.junit.Before;
import org.junit.Test;

public class TestSpecies {
	BufferedReader fileReader1, fileReader2;
	
	@Before
	public void setUp() throws FileNotFoundException {
		fileReader1 = new BufferedReader(new FileReader("Creatures//Flytrap.txt"));
		fileReader2 = new BufferedReader(new FileReader("Creatures//Hop.txt"));
	}
	
	@Test
	public void testSpecies() {
		Species flytrap = new Species(fileReader1);
		Species hop = new Species(fileReader2);
	}

	@Test
	public void testGetSpeciesChar() {
		Species flytrap = new Species(fileReader1);
		Species hop = new Species(fileReader2);
		
		assertEquals(flytrap.getSpeciesChar(), 'F');
		assertEquals(hop.getSpeciesChar(), 'H');
	}

	@Test
	public void testGetName() {
		Species flytrap = new Species(fileReader1);
		Species hop = new Species(fileReader2);
		
		assertEquals(flytrap.getName(), "Flytrap");
		assertEquals(hop.getName(), "Hop");
	}

	@Test
	public void testGetColor() throws FileNotFoundException {
		Species flytrap = new Species(fileReader1);
		Species hop = new Species(fileReader2);
		
		assertEquals(flytrap.getColor(), "magenta");
		assertEquals(hop.getColor(), "blue");
	}

	@Test
	public void testProgramSize() {
		Species flytrap = new Species(fileReader1);
		Species hop = new Species(fileReader2);
		
		assertEquals(flytrap.programSize(), 5);
		assertEquals(hop.programSize(), 2);
		
	}

	@Test(expected=IndexOutOfBoundsException.class)
	public void testProgramStep() {
		Species flytrap = new Species(fileReader1);
		Species hop = new Species(fileReader2);
		
		assertEquals(flytrap.programStep(1).opcode, 8);
		assertEquals(flytrap.programStep(1).address, 4);
		assertEquals(flytrap.programStep(5).opcode, 10);
		assertEquals(flytrap.programStep(5).address, 1);
		
		assertEquals(hop.programStep(1).opcode, 1);
		assertEquals(hop.programStep(1).address, 0);
		assertEquals(hop.programStep(2).opcode, 10);
		assertEquals(hop.programStep(2).address, 1);
		assertEquals(hop.programStep(3).opcode, 0);
		
	}

}
