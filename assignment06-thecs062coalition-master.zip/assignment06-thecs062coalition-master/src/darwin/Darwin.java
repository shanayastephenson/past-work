package darwin;

import structure5.*;

import java.util.ArrayList;
import java.util.Random;
import java.io.*;

/**
 * @author jukim20, shanayastephenson
 * 
 * This class controls the simulation. The design is entirely up to you. You
 * should include a main method that takes the array of species file names
 * passed in and populates a world with species of each type. You class should
 * be able to support anywhere between 1 oto 4 creatures
 * <p>
 * Be sure to call the WorldMap.pause() method every time through the main
 * simulation loop or else the simulation will be too fast. For example:
 * 
 * <pre>
 * public void simulate() {
 * 	for (int rounds = 0; rounds &lt; numRounds; rounds++) {
 * 		giveEachCreatureOneTurn();
 * 		WorldMap.pause(100);
 * 	}
 * }
 * </pre>
 */
class Darwin {
	
	private static World<Creature> testWorld;
	private static Random rand;
	private static final int WORLD_HEIGHT = 20, WORLD_WIDTH = 20;
	private static Species flytrap, hop, rover, food, pooh;
	private static int numRounds = 200;

	/**
	 * The array passed into main will include the arguments that appeared on
	 * the command line. For example, running "java Darwin Hop.txt Rover.txt"
	 * will call the main method with s being an array of two strings: "Hop.txt"
	 * and "Rover.txt".
	 * 
	 * The autograder will always call the full path to the creature files, for
	 * example
	 * "java Darwin /home/user/Desktop/Assignment06/src/darwin/Creatures/Hop.txt"
	 * So please keep all your creates in the Creatures folder under darwin.
	 * 
	 * When running in eclipse, you should be able to access the files using
	 * "./src/Creatures/Hop.txt" as an argument to the file reader. In Run
	 * Configurations -> Arguments, your arguments should be in the format
	 * "./src/Creatures/Hop.txt"
	 * 
	 * This class contains the main program, which is responsible for setting up the world,
	 * populating it with creatures, and running the main loop of the simulation that gives each creature a turn.
	 * The details of these operations are generally handled by the other modules.
	 * New creatures should be created in random empty locations, pointing in random directions.
	 * 
	 */
	public static void main(String s[]) throws FileNotFoundException {
		testWorld = new World<Creature>(WORLD_HEIGHT, WORLD_WIDTH);
		WorldMap.createWorldMap(WORLD_WIDTH, WORLD_HEIGHT);
	
		BufferedReader fileReader1 = new BufferedReader(new FileReader("Creatures//Flytrap.txt"));
		flytrap = new Species(fileReader1);
		
		BufferedReader fileReader2 = new BufferedReader(new FileReader("Creatures//Hop.txt"));
		hop = new Species(fileReader2);
		
		BufferedReader fileReader3 = new BufferedReader(new FileReader("Creatures//Rover.txt"));
		rover = new Species(fileReader3);
		
		BufferedReader fileReader4 = new BufferedReader(new FileReader("Creatures//Food.txt"));
		food = new Species(fileReader4);
		
		BufferedReader fileReader5 = new BufferedReader(new FileReader("Creatures//Pooh.txt"));
		pooh = new Species(fileReader5);
		
		Darwin darwin = new Darwin();
		darwin.simulate();
	}
	
	/**
	 *  creates the creature list, populates the grid and simulates our game.
	 */
	public void simulate() {
		ArrayList<Creature> creatureList = new ArrayList<Creature>();

		for (int i = 0; i <= 10; i++) {
			rand = new Random();
			
			creatureList.add(new Creature(flytrap, testWorld, new Position(rand.nextInt(WORLD_WIDTH), rand.nextInt(WORLD_HEIGHT)), rand.nextInt(4)));
			creatureList.add(new Creature(hop, testWorld, new Position(rand.nextInt(WORLD_WIDTH), rand.nextInt(WORLD_HEIGHT)), rand.nextInt(4)));
			creatureList.add(new Creature(rover, testWorld, new Position(rand.nextInt(WORLD_WIDTH), rand.nextInt(WORLD_HEIGHT)), rand.nextInt(4)));
			creatureList.add(new Creature(food, testWorld, new Position(rand.nextInt(WORLD_WIDTH), rand.nextInt(WORLD_HEIGHT)), rand.nextInt(4)));
			creatureList.add(new Creature(pooh, testWorld, new Position(rand.nextInt(WORLD_WIDTH), rand.nextInt(WORLD_HEIGHT)), rand.nextInt(4)));

		}
		// each creature in the creature list taking a turn, number of rounds times 
		for (int i = 0; i <= numRounds; i++) {
			for(int j = 0; j < creatureList.size(); j++) {
				WorldMap.pause(5);
				creatureList.get(j).takeOneTurn();
			}
		}
		
		// don't forget to call pause somewhere in the simulator's loop...
		// make sure to pause using WorldMap so that TAs can modify pause time
		// when grading
	}
}
