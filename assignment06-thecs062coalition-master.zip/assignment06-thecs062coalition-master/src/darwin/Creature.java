package darwin;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.*;

/**
 * This class represents one creature on the board. Each creature must remember
 * its species, position, direction, and the world in which it is living.
 * <p>
 * In addition, the Creature must remember the next instruction out of its
 * program to execute.
 * <p>
 * The creature is also responsible for making itself appear in the WorldMap. In
 * fact, you should only update the WorldMap from inside the Creature class.
 */

public class Creature {
	protected Species species;
	protected Creature enemy;
	protected World<Creature> world;
	protected Position pos;
	protected int dir;
	protected int current = 1;
	protected Random rand;

	/**
	 * Create a creature of the given species, with the indicated position and
	 * direction. Note that we also pass in the world-- remember this world, so that
	 * you can check what is in front of the creature and update the board when the
	 * creature moves.
	 */
	public Creature(Species species, World<Creature> world, Position pos, int dir) {
		this.species = species;
		this.world = world;
		this.pos = pos;
		this.dir = dir;
		rand = new Random();
		world.set(pos, this);
		WorldMap.displaySquare(pos, species.getSpeciesChar(), dir, species.getColor());
	}

	/**
	 * Return the species of the creature.
	 */
	public Species species() {
		return species;
	}

	/**
	 * Return the current direction of the creature.
	 */
	public int direction() {
		return dir;
	}

	/**
	 * Return the position of the creature.
	 */
	public Position position() {
		return pos;
	}

	/**
	 * Execute steps from the Creature's program until a hop, left, right, or infect
	 * instruction is executed.
	 */
	public void takeOneTurn() {
		
		while (species.programStep(current).getOpcode() > Instruction.INFECT) {
			/* if the adjacent position is null and the position is in range,
			 then continue with that step; else go on with the next instruction */
			if (species.programStep(current).getOpcode() == Instruction.IFEMPTY) {
				if (world.inRange(pos) && world.get(pos.getAdjacent(dir)) == null)
					current = species.programStep(current).getAddress();
				else
					current++;

			/* elseif the position is in range, and adjacent position is not in range
			then continue with that step; then go on with the next instruction		*/
			} else if (species.programStep(current).getOpcode() == Instruction.IFWALL) {
				if (world.inRange(pos) && !world.inRange(pos.getAdjacent(dir)))
					current = species.programStep(current).getAddress();
				else
					current++;
				
			/*elseif the adjacent position is in range, and adjacent position is not null
			  and the position isn't null and the adjacent position's name equals the
			  position's name
			  then continue with that step; then go on with the next instruction */
			} else if (species.programStep(current).getOpcode() == Instruction.IFSAME) {
				if (world.inRange(pos.getAdjacent(dir)) && world.get(pos.getAdjacent(dir)) != null
						&& world.get(pos) != null
						&& world.get(pos.getAdjacent(dir)).species.getName().equals(world.get(pos).species.getName()))
					current = species.programStep(current).getAddress();
				else
					current++;
				
			/* elseif the adjacent position is in range, and adjacent position is not null
		       and the position isn't null and the adjacent position's name does not equal
			   the position's name
			   then continue with that step; then go on with the next instruction
				   */
			} else if (species.programStep(current).getOpcode() == Instruction.IFENEMY) {
				if (world.inRange(pos.getAdjacent(dir)) && world.get(pos.getAdjacent(dir)) != null
						&& world.get(pos) != null && !world.get(pos.getAdjacent(dir)).species.getName()
								.equals(world.get(pos).species.getName())) {
					current = species.programStep(current).getAddress();
				} else {
					current++;
				}
				
			// this instruction gives the creatures better eyesight; the creature now detects enemy 2 squares away from it
			} else if (species.programStep(current).getOpcode() == Instruction.IF2ENEMY) {
				if (world.inRange(pos.getAdjacent(dir).getAdjacent(dir)) && world.get(pos.getAdjacent(dir).getAdjacent(dir)) != null
						&& world.get(pos) != null 
						&& !world.get(pos.getAdjacent(dir).getAdjacent(dir)).species.getName().equals(world.get(pos).species.getName())) {
					current = species.programStep(current).getAddress();
				} else {
					current++;
				}
				
				
			/* this instruction jumps to step n half the time and continues with the next
			 instruction the other half of the time. */
			} else if (species.programStep(current).getOpcode() == Instruction.IFRANDOM) {
				if (rand.nextInt(2) == 0)
					current = species.programStep(current).getAddress();
				else
					current++;
				
			// this instruction always jumps to step n, independent of any condition.
			} else if (species.programStep(current).getOpcode() == Instruction.GO)
				current = species.programStep(current).getAddress();
		}

		/* if the adjacent position is in range, and adjacent position is not null
		 and the position isn't null and the adjacent position's name does not equal
		 the position's name is equal
		 then update the species' species, color, and name 
		 as well as update the display */
		if (species.programStep(current).getOpcode() == Instruction.INFECT) {
			if (world.inRange(pos.getAdjacent(dir)) && world.get(pos.getAdjacent(dir)) != null
					&& !world.get(pos.getAdjacent(dir)).species.getName().equals(world.get(pos).species.getName())) {
				enemy = world.get(pos.getAdjacent(dir));
				enemy.species = species;
				enemy.species.color = species.color;
				enemy.species.name = species.name;

				WorldMap.displaySquare(enemy.position(), species.getSpeciesChar(), enemy.direction(),
						species.getColor());
				
				// If the address is missing, the infected creature should start at step 1.
				if (species.programStep(current).getAddress() == 0)
					enemy.current = 1;
				
				// If there is an address n, move to that address
				else
					enemy.current = species.programStep(current).getAddress();
				
			}
			
		/* The creature moves forward as long as the square it is facing is empty. 
			If moving forward would put the creature outside the boundaries 
			of the world or would cause it to land on top of another creature, the hop instruction does nothing.
			*/
		} else if (species.programStep(current).getOpcode() == Instruction.HOP) {
			if (world.inRange(pos.getAdjacent(dir)) && world.get(pos.getAdjacent(dir)) == null) {
				world.set(pos.getAdjacent(dir), this);
				world.set(pos, null);
				WorldMap.displaySquare(pos, ' ', dir, species.getColor());
				pos = pos.getAdjacent(dir);
				WorldMap.displaySquare(pos, species.getSpeciesChar(), dir, species.getColor());
			}
			
			// The creature turns left 90 degrees to face in a new direction.
		} else if (species.programStep(current).getOpcode() == Instruction.LEFT) {
			if (dir > Position.NORTH)
				dir -= 1;
			else
				dir = Position.WEST;
			WorldMap.displaySquare(pos, species.getSpeciesChar(), dir, species.getColor());
			
			// The creature turns right 90 degrees
		} else if (species.programStep(current).getOpcode() == Instruction.RIGHT) {
			if (dir < Position.WEST)
				dir += 1;
			else
				dir = Position.NORTH;
			WorldMap.displaySquare(pos, species.getSpeciesChar(), dir, species.getColor());

		}

		current++;
	}

	/**
	 * Return the compass direction the is 90 degrees left of the one passed in.
	 */
	public static int leftFrom(int direction) {
		return (4 + direction - 1) % 4;
	}

	/**
	 * Return the compass direction the is 90 degrees right of the one passed in.
	 */
	public static int rightFrom(int direction) {
		return (direction + 1) % 4;
	}

	/**
	 * You may test in the main method if you like, but you could also include a
	 * JUnit test class to check correctness.
	 * 
	 * @throws FileNotFoundException
	 */
	public static void main(String st[]) throws FileNotFoundException {
		BufferedReader fileReader1 = new BufferedReader(new FileReader("Creatures//Flytrap.txt"));
		BufferedReader fileReader2 = new BufferedReader(new FileReader("Creatures//Hop.txt"));
		Species flytrap = new Species(fileReader1);
		Species hop = new Species(fileReader2);

		WorldMap.createWorldMap(5, 5);
		World<Creature> testWorld = new World<Creature>(5, 5);
		Position testPos = new Position(2, 2);
		Position testPos2 = new Position(1, 2);

		// test creature code here.
		Creature testCreature = new Creature(flytrap, testWorld, testPos, Position.WEST);
		Creature testCreature2 = new Creature(hop, testWorld, testPos2, Position.EAST);

		testCreature2.takeOneTurn();
		testCreature.takeOneTurn();

		// uncomment below for compatilibity test with the autograder
		 AutograderCompTest a = new AutograderCompTest();
		 a.testWorld();
		 a.testSpecies();
		 a.testCreature();
		 a.testDarwin();
	}
}
