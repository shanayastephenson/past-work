package sortCompare;

import java.io.*;
import java.util.*;

/**
 * Sorts the data on-disk, by sorting the data in small chunks and then merging
 * the data into one larger chunk
 */
public class OnDiskSort {
	/**
	 * Creates a new sorter for sorting string data on disk. The sorter operates by
	 * reading in maxSize worth of data elements (in this case, Strings) and then
	 * sorts them using the provided sorter. It does this chunk by chunk for all of
	 * the data, at each stage writing the sorted data to temporary files in
	 * workingDirectory. Finally, the sorted files are merged together (in pairs)
	 * until there is a single sorted file. The final output of this sorting should
	 * be in outputFile
	 * 
	 * @param maxSize
	 *            the maximum number of items to put in a chunk
	 * @param workingDirectory
	 *            the directory where any temporary files created during sorting
	 *            should be placed
	 * @param sorter
	 *            the sorter to use to sort the chunks in memory
	 */

	Sorter<String> sorter;
	int maxSize;
	File workingDirectory;
	
	/**
	 * The constructor for OnDiskSort, which includes a sorter, maxSize, 
	 * and a workingDirectory that are all initialized above.
	 * 
	 * @param maxSize
	 * @param workingDirectory
	 * @param sorter
	 */
	public OnDiskSort(int maxSize, File workingDirectory, Sorter<String> sorter) {
		
		// 
		this.sorter = sorter;
		this.maxSize = maxSize;
		this.workingDirectory = workingDirectory;

		// creates temp files
		int tempFileNumber = 0;
		File tempfile = new File(tempFileNumber + ".tempfile");

		// create directory if it doesn't exist
		if (!workingDirectory.exists()) {
			workingDirectory.mkdir();
		}
	}

	/**
	 * Remove all files that that end with fileEnding in workingDirectory
	 * 
	 * If you name all of your temporary files with the same file ending, for
	 * example ".temp_sorted" then it's easy to clean them up using this method
	 * 
	 * @param workingDirectory
	 *            the directory to clear
	 * @param fileEnding
	 *            clear only those files with fileEnding
	 */
	private void clearOutDirectory(File workingDirectory, String fileEnding) {
		for (File file : workingDirectory.listFiles()) {
			if (file.getName().endsWith(fileEnding)) {
				file.delete();
			}
		}
	}

	/**
	 * Write the data in dataToWrite to outfile one String per line
	 * 
	 * @param outfile
	 *            the output file
	 * @param dataToWrite
	 *            the data to write out
	 */
	private void writeToDisk(File outfile, ArrayList<String> dataToWrite) {
		try {
			PrintWriter out = new PrintWriter(new FileOutputStream(outfile));

			for (String s : dataToWrite) {
				out.println(s);
			}

			out.close();
		} catch (IOException e) {
			throw new RuntimeException(e.toString());
		}
	}

	/**
	 * Copy data from fromFile to toFile
	 * 
	 * @param fromFile
	 *            the file to be copied from
	 * @param toFile
	 *            the destination file to be copied to
	 */
	private void copyFile(File fromFile, File toFile) {
		try {
			BufferedReader in = new BufferedReader(new FileReader(fromFile));
			PrintWriter out = new PrintWriter(new FileOutputStream(toFile));

			String line = in.readLine();

			while (line != null) {
				out.println(line);
				line = in.readLine();
			}

			out.close();
			in.close();
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
	}

	/**
	 * Sort the data in data using an on-disk version of sorting
	 * 
	 * @param dataReader
	 *            an Iterator for the data to be sorted
	 * @param outputFile
	 *            the destination for the final sorted data
	 */
	public void sort(Iterator<String> dataReader, File outputFile) throws FileNotFoundException {
		ArrayList<File> tempFileList = new ArrayList<File>();
		ArrayList<String> chunk = new ArrayList<String>();

		int counter = 0;
		
		// while reader has lines in it, add it to chunk
		while (dataReader.hasNext()) {
			chunk.add(dataReader.next());
			// if the list of chunks is less than maxSize, sort the chunks, 
			// create a new file for the sorted chunks to go into, write the sorted chunks onto the disk
			if (chunk.size() > maxSize) {
				sorter.sort(chunk);
				File sortedChunk = new File(workingDirectory, counter + ".tempfile");
				
				// puts the contents of the chunk into the file
				writeToDisk(sortedChunk, chunk);
				tempFileList.add(sortedChunk);
				// the counter goes up by one, changing the name of the next sorted chunk file.
				// clear the chunk list
				counter++;
				chunk.clear();
			}

		}
		mergeFiles(tempFileList, outputFile);
		
		// clears the workingDirectory
		clearOutDirectory(workingDirectory, ".tempfile");

	}

	/**
	 * Merges all the Files in sortedFiles into one sorted file, whose destination
	 * is outputFile.
	 * 
	 * @pre All of the files in sortedFiles contained data that is sorted
	 * @param sortedFiles
	 *            a list of files containing sorted data
	 * @param outputFile
	 *            the destination file for the final sorted data
	 */
	protected void mergeFiles(ArrayList<File> sortedFiles, File outputFile) throws FileNotFoundException {
		// if the size of sortedFiles is 1, then you're done, so just copy the file into the output.
		if (sortedFiles.size() == 1) {
			copyFile(sortedFiles.get(0), outputFile);
		}
		// get the first file, and merge all of the files into the output file, 
		// then copy the outputFile into the first file.
		else {
			File firstFile = sortedFiles.get(0);
		for (int i = 1; i < sortedFiles.size(); i++) {
			merge(sortedFiles.get(i), firstFile, outputFile);
			copyFile(outputFile, firstFile);
		}	
		}
	}

	/**
	 * Given two files containing sorted strings, one string per line, merge them
	 * into one sorted file
	 * 
	 * @param file1
	 *            file containing sorted strings, one per line
	 * @param file2
	 *            file containing sorted strings, one per line
	 * @param outFile
	 *            destination file for the results of merging the two files
	 */
	protected void merge(File file1, File file2, File outFile) throws FileNotFoundException {
		try {
			BufferedReader fileReader = new BufferedReader(new FileReader(file1));
			BufferedReader fileReader2 = new BufferedReader(new FileReader(file2));
			PrintWriter out = new PrintWriter(new FileOutputStream(outFile));
			
			String i = fileReader.readLine();
			String j = fileReader2.readLine();
			
			//while the strings are not null, 
			//  compare them, and if they're not the same, print i, else print j
			while (i != null && j != null) {
				if (i.compareTo(j) <= 0) {
					out.println(i);
					i = fileReader.readLine();
				} else {
					out.println(j);
					j = fileReader2.readLine();
				}
			}
			
			// if either of the lists are lop-sided, print that line
			while (i !=null) {
				out.println(i);
				i = fileReader.readLine();
			}
			while (j !=null) {
				out.println(j);
				j = fileReader2.readLine();
			}
			
			fileReader.close();
			fileReader2.close();
			out.close();
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
		
	}

	/**
	 * Create a sorter that does a mergesort in memory Create a diskSorter to do
	 * external merges Use subdirectory "sorting_run" of your project as the working
	 * directory Create a word scanner to read King's "I have a dream" speech. Sort
	 * all the words of the speech and put them in dile data.sorted
	 * 
	 * @param args
	 *            -- not used!
	 * @throws FileNotFoundException
	 */
	public static void main(String[] args) throws FileNotFoundException {
		MergeSort<String> sorter = new MergeSort<String>();
		OnDiskSort diskSorter = new OnDiskSort(10, new File("sorting_run"), sorter);

		WordScanner scanner = new WordScanner(new File("sorting_run//Ihaveadream.txt"));

		System.out.println("running");
		diskSorter.sort(scanner, new File("sorting_run//data.sorted"));
		System.out.println("done");
		
	}

}
